<?php

defined('_JEXEC') or die;
echo $hi;
echo $value1;
echo $value2;

?>
<div>
	<img src=<?php echo $chartpartone.$value1.",".$value2.$chartparttwo ?>>
	
	
</div>